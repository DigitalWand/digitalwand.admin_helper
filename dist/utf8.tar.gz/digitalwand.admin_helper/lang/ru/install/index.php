<?php
$MESS['ADMIN_HELPER_INSTALL_NAME'] = 'API AdminHelper';
$MESS['ADMIN_HELPER_INSTALL_DESCRIPTION'] = 'API для построения административного интерфейса для highload-инфоблоков';
$MESS['ADMIN_HELPER_INSTALL_TITLE'] = 'Установка модуля "digitalwand.admin_helper"';
$MESS['ADMIN_HELPER_INSTALL_COMPLETE_OK'] = 'Установка завершена.';
$MESS['ADMIN_HELPER_INSTALL_BACK'] = 'Вернуться в управление модулями';
$MESS['ADMIN_HELPER_UNINSTALL_COMPLETE'] = 'Удаление завершено.';