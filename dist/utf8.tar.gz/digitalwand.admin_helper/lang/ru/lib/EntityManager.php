<?php
$MESS['DIGITALWAND_AH_RELATION_SHOULD_BE_MULTIPLE_FIELD'] = "Связь должна быть множественным полем";
$MESS['DIGITALWAND_AH_ARGUMENT_CANT_CONTAIN_ID'] = "Аргумент %A% не может содержать идентификатор элемента";
$MESS['DIGITALWAND_AH_ARGUMENT_SHOULD_CONTAIN_ID'] = "Аргумент %A% должен содержать идентификатор элемента";
