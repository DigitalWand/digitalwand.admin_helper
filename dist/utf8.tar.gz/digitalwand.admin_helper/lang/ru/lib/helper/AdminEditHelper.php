<?php
$MESS['DEFAULT_TAB'] = 'Элемент';
$MESS['DIGITALWAND_ADMIN_HELPER_RETURN_TO_LIST'] = 'Список';
$MESS['DELETE'] = 'Удалить';
$MESS['VALIDATION_ERROR'] = "Не заполнены обязательные поля:\n#FIELD_LIST#";
$MESS['VALIDATION_ERROR_FIELDS'] = "Не заполнены обязательные поля:";
$MESS['DIGITALWAND_ADMIN_HELPER_NEW_ELEMENT'] = "Новый элемент";
$MESS['DIGITALWAND_ADMIN_HELPER_EDIT_TITLE'] = "Элемент #ID#";
$MESS['DIGITALWAND_ADMIN_HELPER_EDIT_DELETE_CONFIRM'] = "Удалить запись?";
$MESS['DIGITALWAND_ADMIN_HELPER_ACTIONS'] = "Действия";
$MESS['DIGITALWAND_ADMIN_HELPER_ADD_ELEMENT'] = "Добавить элемент";
$MESS['DIGITALWAND_ADMIN_HELPER_DELETE_ELEMENT'] = "Удалить элемент";
$MESS['DIGITALWAND_ADMIN_HELPER_EDIT_DELETE_FORBIDDEN'] = 'Не хватает прав доступа для удаления элемента';
$MESS['DIGITALWAND_ADMIN_HELPER_EDIT_WRITE_FORBIDDEN'] = 'Не хватает прав доступа для изменения элемента';
