<?php

$MESS['DIGITALWAND_AH_FAIL_ADD_FILE'] = 'Не удалось добавить файл #FILE_NAME#';