<?php

$MESS['DIGITALWAND_AH_REQUIRED_FIELD_ERROR'] = 'Обязательное поле "#FIELD#" не заполнено';
$MESS['DIGITALWAND_AH_DUPLICATE_FIELD_ERROR'] = 'Значение поля "#FIELD#" не является уникальным';
$MESS['DIGITALWAND_AH_MULTI_NOT_SUPPORT'] = 'Поле не поддерживает множественный режим';
$MESS['DIGITALWAND_AH_MULTI_ADD'] = "Добавить...";