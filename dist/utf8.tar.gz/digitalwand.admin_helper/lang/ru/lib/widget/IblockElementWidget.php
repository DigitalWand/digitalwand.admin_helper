<?php
$MESS['IBLOCK_ELEMENT_NOT_FOUND'] = 'Элемент не найден';