<?php

$MESS['DIGITALWAND_AH_COMBO_BOX_LIST_EMPTY'] = 'Не выбрано';
$MESS['DIGITALWAND_AH_MISSING_VARIANTS'] = 'Не удалось получить данные для выбора';