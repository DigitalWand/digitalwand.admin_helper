<?php

$MESS['TITLE_FIELD_NAME'] = 'Элемент не найден';
$MESS['DIGITALWAND_AH_ORM_MISSING_ELEMENTS'] = 'Элементы не найдены';