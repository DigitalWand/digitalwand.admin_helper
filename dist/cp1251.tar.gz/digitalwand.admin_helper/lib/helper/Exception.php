<?php

namespace DigitalWand\AdminHelper\Helper;

class Exception extends \Exception
{
	const CODE_NO_WIDGET = 1;
	const CODE_NO_HL_ENTITY_INFORMATION = 2;

}